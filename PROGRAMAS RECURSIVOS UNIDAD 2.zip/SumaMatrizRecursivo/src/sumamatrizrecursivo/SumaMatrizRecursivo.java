/*
    ╔═══════════════════════════════════════════╗
    ║     Nombre: Marco Antonio Diaz Diaz       ║
    ║                 Grupo: 2A                 ║ 
    ║ Carrera: Ing. en Sistemas Computacionales ║
    ║            No. Control: 18630307          ║ 
    ╚═══════════════════════════════════════════╝
*/

package sumamatrizrecursivo;

/**
 *
 * @author Marco Antonio Diaz Diaz
 */
public class SumaMatrizRecursivo {

    /**
     * @param args
     */
    public static void main(String[] args) {
        new Execute().exe();
    }

}
